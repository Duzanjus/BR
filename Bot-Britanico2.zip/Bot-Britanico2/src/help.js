const help = (prefix) => { 
	return `   *࿅᪣ᬼ࿅𝔹𝕆𝕋ீ͜ৡৢ͜͡𝔸ℕ𝕁𝕆𝕊᪣ᬽ*
	
		
*╭═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╮*
*║┊:* ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *      
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈  
*║┊:* O CRIADOR : ANJOS
*║┊:* DESENVOLVEDOR : ANJOS
*║┊:* IMPERIO BRASILEIRO DOMINA
*║┊:*      ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ ┈ 
*║┊:◄✜┢┅ீ͜ৡৢ͜͡✦━━◇━━ீ͜ৡৢ͜͡✦┅┧✜►*
*║┊:  * ⃟ ⃟  ━ೋ๑————๑ೋ━* ⃟ ⃟ *   
*╰═┅ৡৢ͜͡✦═══╡꧁꧂╞═══┅ৡৢ͜͡✦═╯*

╭▬▬▬▬▬▬▬▬ *˚✯ཻ⸙۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪۪ࣤ ̥•┉┉•
⊱✦•* ＳＯＢＲＥ Ｏ ＢＯＴ
▋╭┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅┅   
▋┋*${prefix}info
▋┋*${prefix}creador
▋┋*${prefix}speed
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＭＩＤＩＡ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}sticker
▋┋*${prefix}tsticker
▋┋*${prefix}toimg
▋┋*${prefix}randomcat
▋┋*${prefix}wallpaperhd
▋┋*${prefix}tts es <texto>
▋┋*${prefix}pinterest <nombre>
▋┋*${prefix}fototiktok <link>
▋┋*${prefix}tiktok
▋┋*${prefix}ytmp4 <link>
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＣＲＩＡ Ç Ã Ｏ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}firetext <texto | texto>
▋┋*${prefix}snow <texto | texto>
▋┋*${prefix}marvelogo <texto | texto>
▋┋*${prefix}epep <texto | texto>
▋┋*${prefix}text3d <texto | texto>
▋┋*${prefix}textscreen <texto | texto>
▋┋*${prefix}lionlogo <texto | texto>
▋┋*${prefix}water <texto | texto>
▋┋*${prefix}rtext <texto | texto>
▋┋*${prefix}party <texto | texto>
▋┋*${prefix}ninjalogo <texto | texto>
▋┋*${prefix}stiltext <texto | texto>
▋┋*${prefix}lovemake <texto | texto>
▋┋*${prefix}textblue <texto | texto>
▋┋*${prefix}textdark <texto | texto>
▋┋*${prefix}galaxtext <texto | texto>
▋┋*${prefix}quotemarker <texto | texto>
▋┋*${prefix}wolflogo <texto | texto>
▋┋*${prefix}wolflogo2 <texto | texto>
▋┋*${prefix}phlogo <texto | texto>
▋┋*${prefix}glitch <texto | texto>
▋┋*${prefix}tahta <texto | texto>
▋┋*${prefix}thunder <texto | texto>
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＮＩＭＥ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}openanime
▋┋*${prefix}naruto
▋┋*${prefix}minato
▋┋*${prefix}boruto
▋┋*${prefix}hinata
▋┋*${prefix}sasuke
▋┋*${prefix}sakura
▋┋*${prefix}kaneki
▋┋*${prefix}toukacan
▋┋*${prefix}rize
▋┋*${prefix}akira
▋┋*${prefix}itori
▋┋*${prefix}kuromi
▋┋*${prefix}miku
▋┋*${prefix}anime
▋┋*${prefix}nekoanime
▋┋*${prefix}loli
▋┋*${prefix}loli2
▋┋*${prefix}waifu
▋┋*${prefix}waifu2
▋┋*${prefix}wibu
▋┋*${prefix}randomanime
▋┋*${prefix}pokemon
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＩＮＦＯ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}infogc
▋┋*${prefix}groupinfo
▋┋*${prefix}lirik
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＡＤＭＩＮ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}add
▋┋*${prefix}kick
▋┋*${prefix}promote
▋┋*${prefix}demote
▋┋*${prefix}setname
▋┋*${prefix}setdesc
▋┋*${prefix}welcome
▋┋*${prefix}nsfw
▋┋*${prefix}group
▋┋*${prefix}tagme
▋┋*${prefix}hidetag
▋┋*${prefix}tag
▋┋*${prefix}tagall
▋┋*${prefix}infogc
▋┋*${prefix}groupinfo
▋┋*${prefix}linkgroup
▋┋*${prefix}listadmins
▋┋*${prefix}openanime
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＮＳＦＷ  
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}nsfwloli
▋┋*${prefix}nswflowjob
▋┋*${prefix}nsfwneko
▋┋*${prefix}nsfwtrap
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＯＵＴＲＯＳ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}blosklist
▋┋*${prefix}say
▋┋*${prefix}delete
■█■█■█■▰▱▰▱▰▱■█■█■█■
╭────────────────────╮
*➼✰︙ＭＥＮＵ ＤＯ ＣＲＩＡＤＯＲ
╰────────────────────╯
■█■█■█■▰▱▰▱▰▱■█■█■█■
▋┋*${prefix}ban 
▋┋*${prefix}block 
▋┋*${prefix}unblok 
▋┋*${prefix}clearall
▋┋*${prefix}leave
═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡═️ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ۣٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜۜ͜͡♕͜͡
*(•♛•)─•••──ೇุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุุ──────﹒ׂׂૢ་༘࿐ೢִֶָ──╮*
*▄▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▄*        
    *┏ೋ┉━┉ೋ✧ೋ┉━┉ೋ┓*
         🔥 BY :  *ＡＮＪＯＳ* 🔥
    *┗ೋ┉━┉ೋ✧ೋ┉━┉ೋ┛*
*▀▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▀*       
   ۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈͡۝ٜٜٜٜٜٜٜ҈ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ͜҈ٜٜٜٜٜٜٜ͡҈⸙ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ҈ٜٜٜٜ✞ٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜٜ©`
}
exports.help = help
