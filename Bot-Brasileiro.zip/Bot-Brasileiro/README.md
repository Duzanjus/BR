
```bash
>Command BOT $
```

## Instala las dependencias:
Antes de ejecutar el siguiente comando, asegúrese de estar en el directorio del proyecto que
acabas de clonar !!

```bash
> cd Bot-Britanico
> bash install.sh
```

### Uso
```bash
> npm start
```

## Caracteristicas

| :-----------: | :-----------------------------------------------: |
| Sticker Creador |          Característica     |
| :-----------: | :-----------------------------------------------: |
|       ✅       | Enviar foto con pie de foto          
|       ✅       | Responder una foto                    
|       ✅       | Responder a video o GIF             
|       ✅       | Enviar video o GIF con subtítulo   
|       ✅       | Responder un sticker (pegatina a la imagen )               
| :------------: | :---------------------------------------------: |
| Grupo  |                     Característica               
| :-----------: | :----------------------------------------------: |
|       ✅        |   Mencionar a todos.       
|       ✅        |   Eliminar miembros	             
|       ✅        |   Añadir miembros	             
|       ✅        |   Dar lista de Administradores        
| :-----------: | :-----------------------------------------------: |
| creador del Bot  |                     Característica           
| :-----------: | :-----------------------------------------------: |
|       ✅        |   Establecer prefijo                 
|       ✅        |   Difusion                      
|       ✅        |   Vacear todos los chats           
| :--------------: | :--------------------------------------------: |